// Palet warna, text styles (AppColors tetap di sini)
// huruf kecil